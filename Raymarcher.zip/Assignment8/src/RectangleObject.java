import javax.sound.sampled.Line;
import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class RectangleObject extends CollisionObject {

    private int WIDTH;
    private int HEIGHT;

    public RectangleObject(double x, double y, int WIDTH, int HEIGHT) {
        super(x, y);
        this.WIDTH = WIDTH;
        this.HEIGHT = HEIGHT;
    }

    @Override
    public void drawObject(Graphics2D g2d) {
        g2d.setColor(Color.RED);
        Rectangle2D rectangle = new Rectangle2D.Double(getX(), getY(), WIDTH, HEIGHT);
        g2d.fill(rectangle);

    }

    public int getWIDTH() {
        return WIDTH;
    }

    public int getHEIGHT() {
        return HEIGHT;
    }

    @Override
    public double computeDistance(double cameraX, double cameraY) {
        Line2D.Double L1 = new Line2D.Double(getX(), getY(), getX(), getY() + getHEIGHT());
        Line2D.Double L2 = new Line2D.Double(getX(), getY() + getHEIGHT(), getX() + getWIDTH(), getY() + getHEIGHT());
        Line2D.Double L3 = new Line2D.Double(getX() + getWIDTH(), getY()+ getHEIGHT(), getX() + getWIDTH(), getY());
        Line2D.Double L4 = new Line2D.Double(getX() + getWIDTH(), getY(), getX(), getY());
        ArrayList<Line2D.Double> lines = new ArrayList<>();
        lines.add(L1);
        lines.add(L2);
        lines.add(L3);
        lines.add(L4);

        double minDist = Double.MAX_VALUE;

        for (Line2D.Double L : lines){
            minDist = Math.min(minDist, Line2D.ptSegDist(L.x1, L.y1, L.x2, L.y2, cameraX, cameraY));
        }
        return minDist;

    }
}
