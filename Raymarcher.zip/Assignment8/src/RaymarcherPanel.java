import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

/**
 * Displays and updates the logic for the top-down raymarcher.
 */
public class RaymarcherPanel extends JPanel { 
    
    /**
     * We need to keep a reference to the parent swing app for sizing and 
     * other bookkeeping.
     */


    private final RaymarcherRunner raymarcherRunner;
    private List<CollisionObject> objects;
    private Camera camera;

    public RaymarcherPanel(RaymarcherRunner raymarcherRunner) {
        this.raymarcherRunner = raymarcherRunner;
        this.setPreferredSize(new Dimension(this.raymarcherRunner.getFrame().getHeight(), 
                this.raymarcherRunner.getFrame().getHeight()));

        objects = new ArrayList<>();

        // Add some objects to the list
        objects.add(new RectangleObject(50, 50, 50, 50));
        objects.add(new RectangleObject(500, 400,100 , 100));
        objects.add(new CircleObject(200, 130, 25));
        objects.add(new CircleObject(300, 460, 50));

        camera = new Camera(10, 10);
        this.addMouseMotionListener(camera);
        this.addMouseListener(camera);

    }


    public ArrayList<March> march() {
        double currX = this.camera.getX();
        double currY = this.camera.getY();
        ArrayList<March> marches = new ArrayList<>();

        while (currX >= 0 && currX <= this.getPreferredSize().width &&
                currY>= 0 && currY <= this.getPreferredSize().height) {
            double closestDistance = Double.MAX_VALUE;
            for (CollisionObject object : objects) {
                double dist = object.computeDistance(currX, currY);
                if (dist < closestDistance) {
                    closestDistance = dist;
                }
            }

            if (closestDistance < 0.01) break;

            March march = new March(currX, currY, currX + closestDistance, currY);
            marches.add(march);
            currX += closestDistance;
        }

        return marches;
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, this.getWidth(),this.getHeight());

        for (CollisionObject object : objects) {
            object.drawObject(g2d);
        }

        ArrayList<March> marches = march();
        for (March march : marches) {
            march.drawObject(g2d);
        }
        camera.drawObject(g2d);

    }
}
