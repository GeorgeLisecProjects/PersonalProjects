import java.awt.*;
import java.awt.geom.Point2D;

public class March implements Drawable {
    private Point2D start;
    private Point2D end;

    public March(double x1, double y1, double x2, double y2) {
        this.start = new Point2D.Double(x1, y1);
        this.end = new Point2D.Double(x2, y2);
    }

    @Override
    public void drawObject(Graphics2D g2d) {
        g2d.setColor(Color.BLACK);
        g2d.drawLine((int)start.getX(), (int)start.getY(), (int)end.getX(), (int)end.getY());

        int radius = (int)start.distance(end);
        int x = (int)(start.getX() - radius);
        int y = (int)(start.getY() - radius);
        g2d.setColor(Color.RED);
        g2d.drawOval(x, y, radius*2, radius*2);
    }

}