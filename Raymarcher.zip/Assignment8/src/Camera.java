import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;

public class Camera implements Drawable, MouseMotionListener, MouseListener {

    private double x;
    private double y;
    private double angle;
    private final int radius = 10;

    public Camera(double x, double y){
        this.x = x;
        this.y = y;
    }

    @Override
    public void mouseMoved(MouseEvent e){
        x = e.getX();
        y = e.getY();
    }
    @Override
    public void mouseDragged(MouseEvent e){
        //nothing
    }

    public double getX(){
        return x;
    }

    public double getY(){
        return y;
    }

    public int getRadius(){
        return 10;
    }

    public double getAngle(){
        return angle;
    }

    public void setAngle(double angle){
        this.angle = angle;
    }


    public void drawObject(Graphics2D g2d) {
        g2d.setColor(Color.YELLOW);
        Ellipse2D camera = new Ellipse2D.Double(getX() - radius, getY() - radius, radius * 2, radius * 2);
        g2d.fill(camera);
    }

    @Override
    public void mouseClicked(MouseEvent e){

    }

    @Override
    public void mousePressed(MouseEvent e){
        if(e.getButton() == MouseEvent.BUTTON1){
            angle += 1;
        }
        else if (e.getButton() == MouseEvent.BUTTON3){
            angle -= 1;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e){

    }
    @Override
    public void mouseEntered(MouseEvent e){

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }


}
