import java.awt.*;
import java.awt.geom.Ellipse2D;

public class CircleObject extends CollisionObject {

    private int radius;

    public CircleObject(double x, double y, int radius) {
        super(x, y);
        this.radius = radius;
    }

    @Override
    public void drawObject(Graphics2D g2d) {
        g2d.setColor(Color.GREEN);
        Ellipse2D circle = new Ellipse2D.Double(getX() - radius, getY() - radius, radius * 2, radius * 2);
        g2d.fill(circle);
    }

    public int getRadius() {
        return radius;
    }

    @Override
    public double computeDistance(double cameraX, double cameraY) {
        double dx = getX() - cameraX;
        double dy = getY() - cameraY;
        return Math.sqrt(dx * dx + dy * dy) - radius;
    }
}
