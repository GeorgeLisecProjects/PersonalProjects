import java.util.*;

public class Main {
    // Static variables for the TicTacToe class, effectively configuration options
    // Use these instead of hard-coding ' ', 'X', and 'O' as symbols for the game
    // In other words, changing one of these variables should change the program
    // to use that new symbol instead without breaking anything
    // Do NOT add additional static variables to the class!
    static char emptySpaceSymbol = ' ';
    static char playerOneSymbol = 'X';
    static char playerTwoSymbol = 'O';
    public static void main(String[] args) {
        // TODO
        // This is where the main menu system of the program will be written.
        // Hint: Since many of the game runner methods take in an array of player names,
        // you'll probably need to collect names here.
        Scanner in = new Scanner(System.in);
        System.out.println("Welcome to the game of Tic Tac Toe, choose one of the following options from below: ");
        System.out.println("1. Single Player");
        System.out.println("2. Two Player");
        System.out.println("D. Display last match");
        System.out.println("Q. Quit");
        String playerSel = in.next();
        String[] playerNames = new String[2];
        ArrayList<char[][]> gameHistory = new ArrayList<>();
        Random rand = new Random();

        while (!playerSel.equals("Q")) {
            if (playerSel.equals("1")) {
                System.out.print("Enter your name: ");
                playerNames[0] = in.next();
                playerNames[1] = "Computer";
                runOnePlayerGame((playerNames));
            } else if (playerSel.equals("2")) {
                System.out.print("Enter the name of the first player: ");
                playerNames[0] = in.next();
                System.out.print("Enter the name of the second player: ");
                playerNames[1] = in.next();
                int coinFlip = rand.nextInt(2);
                System.out.println("Tossing a coin to decide who goes first!!!");

                String[] shuffledNames = coinToss(playerNames, coinFlip);
                System.out.println(shuffledNames[0] + " gets to go first.");
                runTwoPlayerGame(shuffledNames);

            } else if (playerSel.equals("D")) {
                if (gameHistory.isEmpty()) {
                    System.out.println("No games have been played yet.");
                    return;
                }
                runGameHistory(playerNames, gameHistory);
            } else {
                System.out.println("Invalid menu input.");
            }

            System.out.println("\nWelcome to the game of Tic Tac Toe, choose one of the following options from below: ");
            System.out.println("1. Single Player");
            System.out.println("2. Two Player");
            System.out.println("D. Display last match");
            System.out.println("Q. Quit");
            playerSel = in.next();
        }
        System.out.println("Thanks for playing!");
    }

    public static String[] coinToss(String[] players, int coinChoice) {
        if (coinChoice == 0) {

        } else {

            String temp = players[0];
            players[0] = players[1];
            players[1] = temp;
        }
        return players;
    }

    // Given a state, return a String which is the textual representation of the tic-tac-toe board at that state.
    private static String displayGameFromState(char[][] state) {
        // TODO
        // Hint: Make use of the newline character \n to get everything into one String
        // It would be best practice to do this with a loop, but since we hardcode the game to only use 3x3 boards
        // it's fine to do this without one.
        String display = "";
        for (int p = 0; p < 3; p++) {
            for (int r = 0; r < 3; r++) {
                display += " " + state[p][r];
                if (r < 2) {
                    display += " |";
                }
            }
            if (p < 2) {
                display += "\n-----------\n";
            }
        }
        return display;
    }

    // Returns the state of a game that has just started.
    // This method is implemented for you. You can use it as an example of how to utilize the static class variables.
    // As you can see, you can use it just like any other variable, since it is instantiated and given a value already.
    private static char[][] getInitialGameState() {
        return new char[][]{{emptySpaceSymbol, emptySpaceSymbol, emptySpaceSymbol},
                {emptySpaceSymbol, emptySpaceSymbol, emptySpaceSymbol},
                {emptySpaceSymbol, emptySpaceSymbol, emptySpaceSymbol}};
    }

    // Given the player names, run the two-player game.
    // Return an ArrayList of game states of each turn -- in other words, the gameHistory
    private static ArrayList<char[][]> runTwoPlayerGame(String[] playerNames) {
        ArrayList<char[][]> historyLog = new ArrayList<>();
        char[][] gameBoard = getInitialGameState();
        historyLog.add(gameBoard);
        String playerOne = playerNames[0];
        String playerTwo = playerNames[1];
        ArrayList<char[][]> gameHistory = new ArrayList<>();

        while (true) {
            int[] spaceWanted = getInBoundsPlayerMove(playerOne);
            while (!checkValidMove(spaceWanted, gameBoard)) {
                System.out.println("That space is taken.");
                spaceWanted = getInBoundsPlayerMove(playerOne);
            }
            gameBoard = makeMove(spaceWanted, playerOneSymbol, gameBoard);
            historyLog.add(gameBoard);
            String showBoard = displayGameFromState(gameBoard);
            System.out.println(showBoard);
            if (checkWin(gameBoard, playerOneSymbol)) {
                System.out.println(playerOne + " Wins!");
                break;
            }
            if (checkDraw(gameBoard)) {
                System.out.println("It's a draw.");
                break;
            }

            spaceWanted = getInBoundsPlayerMove(playerTwo);
            while (!checkValidMove(spaceWanted, gameBoard)) {
                System.out.println("That space is taken.");
                spaceWanted = getInBoundsPlayerMove(playerTwo);
            }
            gameBoard = makeMove(spaceWanted, playerTwoSymbol, gameBoard);
            historyLog.add(gameBoard);
            showBoard = displayGameFromState(gameBoard);
            System.out.println(showBoard);
            if (checkWin(gameBoard, playerTwoSymbol)) {
                System.out.println(playerTwo + " Wins!");
                break;
            }
            if (checkDraw(gameBoard)) {
                System.out.println("It's a draw.");
                break;
            }
        }
        if (gameHistory.size() > 0) {
            char[][] emptyBoard = gameHistory.get(0);
            String initialBoard = displayGameFromState(emptyBoard);
            System.out.println(initialBoard);

        } else {
            System.out.println("No game history found.");
        }

        return historyLog;
    }

    // Given the player names (where player two is "Computer"),
    // Run the one-player game.
    // Return an ArrayList of game states of each turn -- in other words, the gameHistory
    public static void runOnePlayerGame(String[] playerNames) {
        String showBoard;
        char[][] gameBoard = getInitialGameState();
        int[] spaceWanted;
        ArrayList<char[][]> historyLog = new ArrayList<>();
        historyLog.add(gameBoard);

        while (true) {

            spaceWanted = getInBoundsPlayerMove(playerNames[0]);

            if (!checkValidMove(spaceWanted, gameBoard)) {
                System.out.println("That space is taken. Try again.");
                continue;
            }
            gameBoard = makeMove(spaceWanted, playerOneSymbol, gameBoard);
            showBoard = displayGameFromState(gameBoard);
            historyLog.add(gameBoard);

            if (checkWin(gameBoard, playerOneSymbol)) {
                System.out.println(showBoard);
                System.out.println(playerNames[0] + " wins!");
                break;
            }

            if (checkDraw(gameBoard)) {
                System.out.println(showBoard);
                System.out.println("It's a draw.");
                break;
            }

            System.out.println(showBoard);


            spaceWanted = getCPUMove(gameBoard);

            gameBoard = makeMove(spaceWanted, playerTwoSymbol, gameBoard);
            showBoard = displayGameFromState(gameBoard);
            historyLog.add(gameBoard);

            if (checkWin(gameBoard, playerTwoSymbol)) {
                System.out.println(showBoard);
                System.out.println("Computer wins!");
                break;
            }

            if (checkDraw(gameBoard)) {
                System.out.println(showBoard);
                System.out.println("It's a draw.");
                break;
            }

            System.out.println(showBoard);
        }
    }

    private static char[][] runPlayerMove(String playerName, char playerSymbol, char[][] currentState) {
        Scanner sc = new Scanner(System.in);
        int[] playerSpace;
        char[][] tempState = new char[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tempState[i][j] = currentState[i][j];
            }
        }

        do {
            playerSpace = getInBoundsPlayerMove(playerName);
            if (!checkValidMove(playerSpace, tempState)) {
                System.out.println("Space is taken, try again! ");
            }
        } while (!checkValidMove(playerSpace, tempState));

        tempState = makeMove(playerSpace, playerSymbol, tempState);

        return tempState;
    }

    // Repeatedly prompts player for move. Returns [row, column] of their desired move such that row & column are on
    // the 3x3 board, but does not check for availability of that space.
    private static int[] getInBoundsPlayerMove(String playerName) {
        Scanner sc = new Scanner(System.in);
        // TODO
        int[] gameSpace = new int[2];
        System.out.println(playerName + "'s turn");
        do {
            System.out.println("Enter a row: ");
            gameSpace[0] = sc.nextInt();
            System.out.println("Enter a column: ");
            gameSpace[1] = sc.nextInt();

            if ((gameSpace[0] < 0 || gameSpace[0] > 2) || (gameSpace[1] < 0 || gameSpace[1] > 2)) {
                System.out.println("That row or column is out of bounds. Try again.");
            }
        }
            while (gameSpace[0] < 0 || gameSpace[0] > 2 || gameSpace[1] > 2) ;
            return gameSpace;

        }


    // Given a [row, col] move, return true if a space is unclaimed.
    // Doesn't need to check whether move is within bounds of the board.
        private static boolean checkValidMove(int[] move, char[][] state) {
            // TODO
            int row = move[0];
            int column = move[1];
            if (state[row][column] == emptySpaceSymbol) {
                return true;
            }
            return false;
        }

    // Given a [row, col] move, the symbol to add, and a game state,
    // Return a NEW array (do NOT modify the argument currentState) with the new game state
    private static char[][] makeMove(int[] move, char symbol, char[][] currentState) {
        int row = move[0];
        int col = move[1];

        char[][] newState = new char[currentState.length][];
        for (int i = 0; i < currentState.length; i++) {
            newState[i] = Arrays.copyOf(currentState[i], currentState[i].length);
        }

        newState[row][col] = symbol;
        return newState;
    }


    // Given a state, return true if some player has won in that state
    private static boolean checkWin(char[][] state, char playerOneSymbol) {
        // TODO
        // Hint: no need to check if player one has won and if player two has won in separate steps,
        // you can just check if the same symbol occurs three times in any row, col, or diagonal (except empty space symbol)
        // But either implementation is valid: do whatever makes most sense to you.

        // Horizontals
        for(int i = 0; i < 3; i++){
            if(state[i][0] != ' '){
                if(state[i][0] == state [i][1]){
                    if(state[i][1] == state [i][2]){
                        return true;
                    }
                }
            }
        }
        // Verticals
        for(int j = 0; j<3; j++){
            if (state[0][j] != ' ') {
                if (state[0][j] == state[1][j]) {
                    if (state[1][j] == state[2][j]) {
                        return true;
                    }
                }
            }
        }
        // Diagonals
        if (state[1][1] != ' ') {
            if (state[0][0] == state[1][1]) {
                if (state[1][1] == state[2][2]) {
                    return true;
                }
            }
            if (state[2][0] == state[1][1]) {
                if (state[1][1] == state[0][2]) {
                    return true;
                }
            }
        }
        return false;
    }

    // Given a state, simply checks whether all spaces are occupied. Does not care or check if a player has won.
    private static boolean checkDraw(char[][] state) {
        for (int i = 0; i < state.length; i++) {
            for (int j = 0; j < state[i].length; j++) {
                if (state[i][j] == ' ') {
                    return false;
                }
            }
        }
        return false;
    }

    // Given a game state, return a new game state with move from the AI
    // It follows the algorithm in the PDF to ensure a tie (or win if possible)
    private static int[] getCPUMove(char[][] gameState) {
        int[] RowColumn = new int[2];
        char[][] tempState = new char[3][3];
        Random ran = new Random();

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tempState[i][j] = gameState[i][j];
            }
        }

        RowColumn[0] = ran.nextInt(3);
        RowColumn[1] = ran.nextInt(3);

        if (checkValidMove(RowColumn, tempState)) {
            tempState[RowColumn[0]][RowColumn[1]] = playerTwoSymbol;
        } else {
            while (!checkValidMove(RowColumn, tempState)) {
                RowColumn[0] = ran.nextInt(3);
                RowColumn[1] = ran.nextInt(3);
            }
            tempState[RowColumn[0]][RowColumn[1]] = playerTwoSymbol;
        }

        return RowColumn;
    }

    // Given a game state, return an ArrayList of [row, column] positions that are unclaimed on the board
    private static ArrayList<int[]> getValidMoves(char[][] gameState) {
        // TODO
        ArrayList<int[]> openSpaces = new ArrayList<>();
        for (int i = 0; i < gameState.length; i++) {
            for (int j = 0; j < gameState.length; j++) {
                int[] tempRowCol = {i, j};
                if (checkValidMove(tempRowCol, gameState)) {
                    openSpaces.add(tempRowCol);
                }
            }
        }
        return openSpaces;
    }

    // Given player names and the game history, display the past game as in the PDF sample code output
    private static void runGameHistory(String[] playerNames, ArrayList<char[][]> gameHistory) {
        // TODO
        // We have the names of the players in the format [playerOneName, playerTwoName]
        // Player one always gets 'X' while player two always gets 'O'
        // However, we do not know yet which player went first, but we'll need to know...
        // Hint for the above: which symbol appears after one turn is taken?


        // Hint: iterate over gameHistory using a loop

        char playerOneSymbol = 'X';
        char playerTwoSymbol = 'O';

        if (playerNames[0].equals("Computer")) {
            // If the first player is the computer, assign 'O' to the second player
            playerTwoSymbol = 'O';
        } else {
            // If the first player is a human player, assign 'O' to the second player
            playerTwoSymbol = 'X';
        }

        System.out.println(playerNames[0] + " (x) vs " + playerNames[1] + " (0)");
        char[][] emptyBoard = gameHistory.get(0);
        String initialBoard = displayGameFromState(emptyBoard);
        System.out.println(initialBoard);
        char[][] holdsCurrentGameBoard;
        String board;


        for (int i = 1; i < gameHistory.size(); i++) {


            if (i % 2 != 0) {
                System.out.println(playerNames + ":");
                holdsCurrentGameBoard = gameHistory.get(i);
                board = displayGameFromState(holdsCurrentGameBoard);
                System.out.println(board);
                if (checkWin(holdsCurrentGameBoard, playerOneSymbol)) {
                    System.out.println(playerNames[0] + "wins");
                }
            } else {
                System.out.println(playerNames + ":");
                holdsCurrentGameBoard = gameHistory.get(i);
                board = displayGameFromState(holdsCurrentGameBoard);
                System.out.println(board);
                if (checkWin(holdsCurrentGameBoard, playerTwoSymbol)) {
                    System.out.println(playerNames[1] + "wins");
                }


            }
            if (checkDraw(holdsCurrentGameBoard)) {
                System.out.println("It's a Draw.");
            }


        }
    }
}
